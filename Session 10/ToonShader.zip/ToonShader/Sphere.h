#pragma once
#include <glm/gtc/matrix_transform.hpp>
#include <glm/gtc/type_ptr.hpp>
#include <glm/gtc/matrix_inverse.hpp>
#include "vertex.h"

using namespace glm;

class Sphere
{
private:
	vec3 Position;
	VertexWtihNormal* sphereVerticesNor;  //Sphere vertices data with normals
	unsigned int* sphereIndices;          //Sphere triangle indices    

	int stacks; // nunber of segments
	int slices; // number of segments
	float radius;

	void CreateSpherewithNormal();
public:
	Sphere();
	~Sphere();

	void SetPosition(vec3 newPos);
	vec3 GetPosition(void);
	VertexWtihNormal* GetVerData(int&);
	unsigned int* GetTriData(int&);
};

