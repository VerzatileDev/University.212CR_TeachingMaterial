#ifndef SHADER_H
#define SHADER_H

int setShader(const char* shaderType, const char* shaderFile);

#endif