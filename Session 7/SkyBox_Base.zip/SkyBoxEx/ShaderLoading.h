#pragma once
#include <GL/glew.h>
#include <GL/freeglut.h>
#pragma comment(lib, "glew32.lib") 

#include <iostream>
#include <vector>

void shaderCompileTest(GLuint shader);

char* readTextFile(std::string aTextFile);