#pragma once
#include <iostream>
#include <fstream>

#include <GL/glew.h>
#include <GL/freeglut.h>
#pragma comment(lib, "glew32.lib") 

#include <filesystem>
#include "soil/SOIL.h"

#include <glm/glm.hpp>
#include <glm/gtc/matrix_transform.hpp>
#include <glm/gtc/type_ptr.hpp>

#include "ShaderLoading.h"

class Skybox
{
private:
	unsigned int skyboxVAO,
		skyboxVBO,

		textureID,
		programId,
		vertexShaderId,
		fragmentShaderId,

		myTextureIDs[1];
public:
	Skybox();
	~Skybox();

	void CreateShader(std::string vertName, std::string fragName);
	void InitialiseSkybox();
	void InitialiseCubeMap();

	void Bind();
	void Draw();
	void SetViewMatrix(glm::mat4 viewMatrix);
	void SetProjectionMatrix(glm::mat4 projectionMatrix);
};

